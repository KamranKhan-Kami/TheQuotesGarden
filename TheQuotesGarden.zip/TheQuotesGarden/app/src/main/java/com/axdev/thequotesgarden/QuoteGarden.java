package com.axdev.thequotesgarden;

import android.app.Application;
import android.widget.Toast;

/**
 * Created by CH_M_USMAN on 10-Jun-17.
 */

public class QuoteGarden extends Application {
    @Override
    public void onCreate() {
        super.onCreate();

    }
}
